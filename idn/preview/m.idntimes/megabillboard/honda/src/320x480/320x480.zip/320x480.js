(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"320x480_atlas_", frames: [[1610,0,320,480],[966,0,320,480],[644,0,320,480],[1288,0,320,480],[0,482,320,480],[322,482,320,480],[644,482,320,480],[0,0,320,480],[322,0,320,480],[0,964,320,480],[1288,964,320,480],[966,482,320,480],[322,964,320,480],[1288,482,320,480],[644,964,320,480],[966,964,320,480],[1610,482,320,480]]}
];


// symbols:



(lib.awardglow = function() {
	this.initialize(ss["320x480_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.award1 = function() {
	this.initialize(ss["320x480_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.award2 = function() {
	this.initialize(ss["320x480_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.bg1 = function() {
	this.initialize(ss["320x480_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.bgblack = function() {
	this.initialize(ss["320x480_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib._break = function() {
	this.initialize(ss["320x480_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.ctacopy = function() {
	this.initialize(ss["320x480_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.cta = function() {
	this.initialize(ss["320x480_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.glow1 = function() {
	this.initialize(ss["320x480_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.honda = function() {
	this.initialize(ss["320x480_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.hp = function() {
	this.initialize(ss["320x480_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.join = function() {
	this.initialize(ss["320x480_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.logo = function() {
	this.initialize(ss["320x480_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.mobil = function() {
	this.initialize(ss["320x480_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.parkirglow = function() {
	this.initialize(ss["320x480_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.parkir = function() {
	this.initialize(ss["320x480_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.weareready = function() {
	this.initialize(ss["320x480_atlas_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.Tween32 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.honda();
	this.instance.parent = this;
	this.instance.setTransform(-160,-240);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,320,480);


(lib.Tween31 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.honda();
	this.instance.parent = this;
	this.instance.setTransform(-160,-240);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,320,480);


(lib.Tween30 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.bg1();
	this.instance.parent = this;
	this.instance.setTransform(-160,-240);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,320,480);


(lib.Tween29 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.bg1();
	this.instance.parent = this;
	this.instance.setTransform(-160,-240);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,320,480);


(lib.Tween28 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ctacopy();
	this.instance.parent = this;
	this.instance.setTransform(-160,-240);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,320,480);


(lib.Tween27 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ctacopy();
	this.instance.parent = this;
	this.instance.setTransform(-160,-240);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,320,480);


(lib.Tween26 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.cta();
	this.instance.parent = this;
	this.instance.setTransform(-160,-240);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,320,480);


(lib.Tween25 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.cta();
	this.instance.parent = this;
	this.instance.setTransform(-160,-240);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,320,480);


(lib.Tween24 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.weareready();
	this.instance.parent = this;
	this.instance.setTransform(-160,-240);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,320,480);


(lib.Tween23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.weareready();
	this.instance.parent = this;
	this.instance.setTransform(-160,-240);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,320,480);


(lib.Tween22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.parkirglow();
	this.instance.parent = this;
	this.instance.setTransform(-160,-240);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,320,480);


(lib.Tween21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.parkirglow();
	this.instance.parent = this;
	this.instance.setTransform(-160,-240);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,320,480);


(lib.Tween20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.parkir();
	this.instance.parent = this;
	this.instance.setTransform(-160,-240);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,320,480);


(lib.Tween19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.parkir();
	this.instance.parent = this;
	this.instance.setTransform(-160,-240);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,320,480);


(lib.Tween18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.join();
	this.instance.parent = this;
	this.instance.setTransform(-160,-240);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,320,480);


(lib.Tween17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.join();
	this.instance.parent = this;
	this.instance.setTransform(-160,-240);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,320,480);


(lib.Tween16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.mobil();
	this.instance.parent = this;
	this.instance.setTransform(-160,-240);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,320,480);


(lib.Tween15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.mobil();
	this.instance.parent = this;
	this.instance.setTransform(-160,-240);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,320,480);


(lib.Tween14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.logo();
	this.instance.parent = this;
	this.instance.setTransform(-160,-240);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,320,480);


(lib.Tween13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.logo();
	this.instance.parent = this;
	this.instance.setTransform(-160,-240);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,320,480);


(lib.Tween12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.awardglow();
	this.instance.parent = this;
	this.instance.setTransform(-160,-240);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,320,480);


(lib.Tween11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.awardglow();
	this.instance.parent = this;
	this.instance.setTransform(-160,-240);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,320,480);


(lib.Tween10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.award2();
	this.instance.parent = this;
	this.instance.setTransform(-160,-240);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,320,480);


(lib.Tween9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.award2();
	this.instance.parent = this;
	this.instance.setTransform(-160,-240);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,320,480);


(lib.Tween8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.award1();
	this.instance.parent = this;
	this.instance.setTransform(-160,-240);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,320,480);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.award1();
	this.instance.parent = this;
	this.instance.setTransform(-160,-240);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,320,480);


(lib.Tween6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib._break();
	this.instance.parent = this;
	this.instance.setTransform(-160,-240);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,320,480);


(lib.Tween5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib._break();
	this.instance.parent = this;
	this.instance.setTransform(-160,-240);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,320,480);


(lib.Tween4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.glow1();
	this.instance.parent = this;
	this.instance.setTransform(-160,-240);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,320,480);


(lib.Tween3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.glow1();
	this.instance.parent = this;
	this.instance.setTransform(-160,-240);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,320,480);


(lib.Tween2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.hp();
	this.instance.parent = this;
	this.instance.setTransform(-160,-240);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,320,480);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.hp();
	this.instance.parent = this;
	this.instance.setTransform(-160,-240);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,320,480);


(lib.Scene_1_bg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// bg
	this.instance = new lib.bgblack();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(360));

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_weareready = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// weareready
	this.instance = new lib.Tween23("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(160,240);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.instance_1 = new lib.Tween24("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(160,240);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(202).to({_off:false},0).to({_off:true,alpha:1},10).wait(61));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(202).to({_off:false},10).wait(51).to({startPosition:0},0).to({alpha:0},9).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_parkir_glow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// parkir_glow
	this.instance = new lib.Tween21("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(160,240);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.instance_1 = new lib.Tween22("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(160,240);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(212).to({_off:false},0).to({_off:true,alpha:1},10).wait(113));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(212).to({_off:false},10).to({alpha:0},10).to({alpha:1},10).to({alpha:0},10).to({alpha:1},11).to({y:122.55,alpha:0},9).to({alpha:1},10).to({alpha:0},10).to({alpha:1},10).wait(23).to({startPosition:0},0).to({alpha:0},9).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_parkir = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// parkir
	this.instance = new lib.Tween19("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(160,240);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.instance_1 = new lib.Tween20("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(160,240);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(212).to({_off:false},0).to({_off:true,alpha:1},10).wait(113));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(212).to({_off:false},10).wait(41).to({startPosition:0},0).to({y:122.55},9).wait(53).to({startPosition:0},0).to({alpha:0},9).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_mobil = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// mobil
	this.instance = new lib.Tween15("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(160,240);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.instance_1 = new lib.Tween16("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(160,240);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(146).to({_off:false},0).to({_off:true,alpha:1},10).wait(47));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(146).to({_off:false},10).wait(37).to({startPosition:0},0).to({alpha:0},9).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_logohonda = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// logohonda
	this.instance = new lib.Tween31("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(160,240);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.instance_1 = new lib.Tween32("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(160,240);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},334).to({state:[{t:this.instance_1}]},10).wait(16));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(334).to({_off:false},0).to({_off:true,alpha:1},10).wait(16));

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_join = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// join
	this.instance = new lib.Tween17("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(160,240);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.instance_1 = new lib.Tween18("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(160,240);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(136).to({_off:false},0).to({_off:true,alpha:1},10).wait(57));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(136).to({_off:false},10).wait(47).to({startPosition:0},0).to({alpha:0},9).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_hp = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// hp
	this.instance = new lib.Tween1("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(160,240,0.625,0.625);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.instance_1 = new lib.Tween2("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(160,240);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(5).to({_off:false},0).to({_off:true,scaleX:1,scaleY:1,alpha:1},14,cjs.Ease.quartOut).wait(118));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(5).to({_off:false},14,cjs.Ease.quartOut).wait(108).to({startPosition:0},0).to({alpha:0},9).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_glowdasar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// glowdasar
	this.instance = new lib.Tween3("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(160,240);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.instance_1 = new lib.Tween4("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(160,240);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(29).to({_off:false},0).to({_off:true,alpha:1},15,cjs.Ease.quadIn).wait(93));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(29).to({_off:false},15,cjs.Ease.quadIn).to({alpha:0.1992},15).to({alpha:1},15,cjs.Ease.quadIn).to({alpha:0.1992},15).to({alpha:1},15).wait(23).to({startPosition:0},0).to({alpha:0},9).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_ctatext = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// ctatext
	this.instance = new lib.Tween27("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(160,240);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.instance_1 = new lib.Tween28("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(160,240);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(282).to({_off:false},0).to({_off:true,alpha:1},10).wait(43));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(282).to({_off:false},10).wait(33).to({startPosition:0},0).to({alpha:0},9).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// cta
	this.instance = new lib.Tween25("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(160,322.4,0.0313,0.0313);
	this.instance._off = true;

	this.instance_1 = new lib.Tween26("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(160,240);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(272).to({_off:false},0).to({_off:true,scaleX:1,scaleY:1,y:240},10,cjs.Ease.quadOut).wait(53));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(272).to({_off:false},10,cjs.Ease.quadOut).wait(43).to({startPosition:0},0).to({alpha:0},9).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_brio = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// brio
	this.instance = new lib.logo();
	this.instance.parent = this;

	this.instance_1 = new lib.Tween13("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(160,240);
	this.instance_1._off = true;

	this.instance_2 = new lib.Tween14("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(160,240);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance}]},74).to({state:[{t:this.instance_1}]},53).to({state:[{t:this.instance_2}]},9).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(127).to({_off:false},0).to({_off:true,alpha:0},9).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_break_idn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// break_idn
	this.instance = new lib.Tween5("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(160,240);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.instance_1 = new lib.Tween6("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(160,240);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(19).to({_off:false},0).to({_off:true,alpha:1},10,cjs.Ease.quadOut).wait(26));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(19).to({_off:false},10,cjs.Ease.quadOut).wait(16).to({startPosition:0},0).to({alpha:0},9).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_bg1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// bg1
	this.instance = new lib.bg1();
	this.instance.parent = this;

	this.instance_1 = new lib.Tween29("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(160,240);
	this.instance_1._off = true;

	this.instance_2 = new lib.Tween30("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(160,240);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance}]},74).to({state:[{t:this.instance_1}]},250).to({state:[{t:this.instance_2}]},10).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(324).to({_off:false},0).to({_off:true,alpha:0},10).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_award2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// award2
	this.instance = new lib.Tween9("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(183.25,313.4,0.625,0.625);
	this.instance._off = true;

	this.instance_1 = new lib.Tween10("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(160,240);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(69).to({_off:false},0).to({_off:true,scaleX:1,scaleY:1,x:160,y:240},10,cjs.Ease.quadOut).wait(58));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(69).to({_off:false},10,cjs.Ease.quadOut).wait(48).to({startPosition:0},0).to({alpha:0},9).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_award1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// award1
	this.instance = new lib.Tween7("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(129.4,315.3,0.625,0.625);
	this.instance._off = true;

	this.instance_1 = new lib.Tween8("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(160,240);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(59).to({_off:false},0).to({_off:true,scaleX:1,scaleY:1,x:160,y:240},10,cjs.Ease.quadOut).wait(68));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(59).to({_off:false},10,cjs.Ease.quadOut).wait(58).to({startPosition:0},0).to({alpha:0},9).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_award_glow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// award_glow
	this.instance = new lib.Tween11("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(160,240);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.instance_1 = new lib.Tween12("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(160,240);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(79).to({_off:false},0).to({_off:true,alpha:1},10,cjs.Ease.quadOut).wait(48));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(79).to({_off:false},10,cjs.Ease.quadOut).to({alpha:0.5},10).to({alpha:1},10).to({alpha:0},10).to({alpha:1},8).to({alpha:0},9).wait(1));

}).prototype = p = new cjs.MovieClip();


// stage content:
(lib._320x480 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.___GetDepth___ = function(obj) {
		var depth = obj.depth;
		var cameraObj = this.___camera___instance;
		if(cameraObj && cameraObj.depth && obj.isAttachedToCamera)
		{
			depth += depth + cameraObj.depth;
		}
		return depth;
		}
	this.___needSorting___ = function() {
		for (var i = 0; i < this.getNumChildren() - 1; i++)
		{
			var prevDepth = this.___GetDepth___(this.getChildAt(i));
			var nextDepth = this.___GetDepth___(this.getChildAt(i + 1));
			if (prevDepth < nextDepth)
				return true;
		}
		return false;
	}
	this.___sortFunction___ = function(obj1, obj2) {
		return (this.exportRoot.___GetDepth___(obj2) - this.exportRoot.___GetDepth___(obj1));
	}
	this.on('tick', function (event){
		var curTimeline = event.currentTarget;
		if (curTimeline.___needSorting___()){
			this.sortChildren(curTimeline.___sortFunction___);
		}
	});

	// timeline functions:
	this.frame_359 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(359).call(this.frame_359).wait(1));

	// logohonda_obj_
	this.logohonda = new lib.Scene_1_logohonda();
	this.logohonda.name = "logohonda";
	this.logohonda.parent = this;
	this.logohonda.depth = 0;
	this.logohonda.isAttachedToCamera = 0
	this.logohonda.isAttachedToMask = 0
	this.logohonda.layerDepth = 0
	this.logohonda.layerIndex = 0
	this.logohonda.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.logohonda).wait(360));

	// ctatext_obj_
	this.ctatext = new lib.Scene_1_ctatext();
	this.ctatext.name = "ctatext";
	this.ctatext.parent = this;
	this.ctatext.depth = 0;
	this.ctatext.isAttachedToCamera = 0
	this.ctatext.isAttachedToMask = 0
	this.ctatext.layerDepth = 0
	this.ctatext.layerIndex = 1
	this.ctatext.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.ctatext).wait(334).to({_off:true},1).wait(25));

	// cta_obj_
	this.cta = new lib.Scene_1_cta();
	this.cta.name = "cta";
	this.cta.parent = this;
	this.cta.depth = 0;
	this.cta.isAttachedToCamera = 0
	this.cta.isAttachedToMask = 0
	this.cta.layerDepth = 0
	this.cta.layerIndex = 2
	this.cta.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(334).to({_off:true},1).wait(25));

	// parkir_obj_
	this.parkir = new lib.Scene_1_parkir();
	this.parkir.name = "parkir";
	this.parkir.parent = this;
	this.parkir.depth = 0;
	this.parkir.isAttachedToCamera = 0
	this.parkir.isAttachedToMask = 0
	this.parkir.layerDepth = 0
	this.parkir.layerIndex = 3
	this.parkir.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.parkir).wait(334).to({_off:true},1).wait(25));

	// parkir_glow_obj_
	this.parkir_glow = new lib.Scene_1_parkir_glow();
	this.parkir_glow.name = "parkir_glow";
	this.parkir_glow.parent = this;
	this.parkir_glow.depth = 0;
	this.parkir_glow.isAttachedToCamera = 0
	this.parkir_glow.isAttachedToMask = 0
	this.parkir_glow.layerDepth = 0
	this.parkir_glow.layerIndex = 4
	this.parkir_glow.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.parkir_glow).wait(334).to({_off:true},1).wait(25));

	// weareready_obj_
	this.weareready = new lib.Scene_1_weareready();
	this.weareready.name = "weareready";
	this.weareready.parent = this;
	this.weareready.depth = 0;
	this.weareready.isAttachedToCamera = 0
	this.weareready.isAttachedToMask = 0
	this.weareready.layerDepth = 0
	this.weareready.layerIndex = 5
	this.weareready.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.weareready).wait(272).to({_off:true},1).wait(87));

	// mobil_obj_
	this.mobil = new lib.Scene_1_mobil();
	this.mobil.name = "mobil";
	this.mobil.parent = this;
	this.mobil.depth = 0;
	this.mobil.isAttachedToCamera = 0
	this.mobil.isAttachedToMask = 0
	this.mobil.layerDepth = 0
	this.mobil.layerIndex = 6
	this.mobil.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.mobil).wait(202).to({_off:true},1).wait(157));

	// join_obj_
	this.join = new lib.Scene_1_join();
	this.join.name = "join";
	this.join.parent = this;
	this.join.depth = 0;
	this.join.isAttachedToCamera = 0
	this.join.isAttachedToMask = 0
	this.join.layerDepth = 0
	this.join.layerIndex = 7
	this.join.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.join).wait(202).to({_off:true},1).wait(157));

	// award2_obj_
	this.award2 = new lib.Scene_1_award2();
	this.award2.name = "award2";
	this.award2.parent = this;
	this.award2.depth = 0;
	this.award2.isAttachedToCamera = 0
	this.award2.isAttachedToMask = 0
	this.award2.layerDepth = 0
	this.award2.layerIndex = 8
	this.award2.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.award2).wait(136).to({_off:true},1).wait(223));

	// award1_obj_
	this.award1 = new lib.Scene_1_award1();
	this.award1.name = "award1";
	this.award1.parent = this;
	this.award1.depth = 0;
	this.award1.isAttachedToCamera = 0
	this.award1.isAttachedToMask = 0
	this.award1.layerDepth = 0
	this.award1.layerIndex = 9
	this.award1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.award1).wait(136).to({_off:true},1).wait(223));

	// award_glow_obj_
	this.award_glow = new lib.Scene_1_award_glow();
	this.award_glow.name = "award_glow";
	this.award_glow.parent = this;
	this.award_glow.depth = 0;
	this.award_glow.isAttachedToCamera = 0
	this.award_glow.isAttachedToMask = 0
	this.award_glow.layerDepth = 0
	this.award_glow.layerIndex = 10
	this.award_glow.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.award_glow).wait(136).to({_off:true},1).wait(223));

	// break_idn_obj_
	this.break_idn = new lib.Scene_1_break_idn();
	this.break_idn.name = "break_idn";
	this.break_idn.parent = this;
	this.break_idn.depth = 0;
	this.break_idn.isAttachedToCamera = 0
	this.break_idn.isAttachedToMask = 0
	this.break_idn.layerDepth = 0
	this.break_idn.layerIndex = 11
	this.break_idn.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.break_idn).wait(54).to({_off:true},1).wait(305));

	// hp_obj_
	this.hp = new lib.Scene_1_hp();
	this.hp.name = "hp";
	this.hp.parent = this;
	this.hp.depth = 0;
	this.hp.isAttachedToCamera = 0
	this.hp.isAttachedToMask = 0
	this.hp.layerDepth = 0
	this.hp.layerIndex = 12
	this.hp.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.hp).wait(136).to({_off:true},1).wait(223));

	// glowdasar_obj_
	this.glowdasar = new lib.Scene_1_glowdasar();
	this.glowdasar.name = "glowdasar";
	this.glowdasar.parent = this;
	this.glowdasar.depth = 0;
	this.glowdasar.isAttachedToCamera = 0
	this.glowdasar.isAttachedToMask = 0
	this.glowdasar.layerDepth = 0
	this.glowdasar.layerIndex = 13
	this.glowdasar.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.glowdasar).wait(136).to({_off:true},1).wait(223));

	// brio_obj_
	this.brio = new lib.Scene_1_brio();
	this.brio.name = "brio";
	this.brio.parent = this;
	this.brio.setTransform(160,240,1,1,0,0,0,160,240);
	this.brio.depth = 0;
	this.brio.isAttachedToCamera = 0
	this.brio.isAttachedToMask = 0
	this.brio.layerDepth = 0
	this.brio.layerIndex = 14
	this.brio.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.brio).wait(136).to({_off:true},1).wait(223));

	// bg1_obj_
	this.bg1 = new lib.Scene_1_bg1();
	this.bg1.name = "bg1";
	this.bg1.parent = this;
	this.bg1.setTransform(160,240,1,1,0,0,0,160,240);
	this.bg1.depth = 0;
	this.bg1.isAttachedToCamera = 0
	this.bg1.isAttachedToMask = 0
	this.bg1.layerDepth = 0
	this.bg1.layerIndex = 15
	this.bg1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.bg1).wait(334).to({_off:true},1).wait(25));

	// bg_obj_
	this.bg = new lib.Scene_1_bg();
	this.bg.name = "bg";
	this.bg.parent = this;
	this.bg.setTransform(160,240,1,1,0,0,0,160,240);
	this.bg.depth = 0;
	this.bg.isAttachedToCamera = 0
	this.bg.isAttachedToMask = 0
	this.bg.layerDepth = 0
	this.bg.layerIndex = 16
	this.bg.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(360));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(160,122.6,160,357.4);
// library properties:
lib.properties = {
	id: 'CF119B681F39104A8CB785EB8D1D7994',
	width: 320,
	height: 480,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/320x480_atlas_.png", id:"320x480_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['CF119B681F39104A8CB785EB8D1D7994'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


// Layer depth API : 

AdobeAn.Layer = new function() {
	this.getLayerZDepth = function(timeline, layerName)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline." + layerName + ".depth; else 0;";
		return eval(script);
	}
	this.setLayerZDepth = function(timeline, layerName, zDepth)
	{
		const MAX_zDepth = 10000;
		const MIN_zDepth = -5000;
		if(zDepth > MAX_zDepth)
			zDepth = MAX_zDepth;
		else if(zDepth < MIN_zDepth)
			zDepth = MIN_zDepth;
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline." + layerName + ".depth = " + zDepth + ";";
		eval(script);
	}
	this.removeLayer = function(timeline, layerName)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline.removeChild(timeline." + layerName + ");";
		eval(script);
	}
	this.addNewLayer = function(timeline, layerName, zDepth)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		zDepth = typeof zDepth !== 'undefined' ? zDepth : 0;
		var layer = new createjs.MovieClip();
		layer.name = layerName;
		layer.depth = zDepth;
		layer.layerIndex = 0;
		timeline.addChild(layer);
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;